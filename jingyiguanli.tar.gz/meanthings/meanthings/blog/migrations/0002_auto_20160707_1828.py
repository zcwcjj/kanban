# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('blog', '0001_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='article',
            name='content',
            field=models.TextField(max_length=5000, verbose_name='内容'),
        ),
        migrations.AlterField(
            model_name='article',
            name='createDate',
            field=models.DateField(verbose_name='填写日期'),
        ),
        migrations.AlterField(
            model_name='article',
            name='title',
            field=models.CharField(max_length=100, verbose_name='标题'),
        ),
        migrations.AlterField(
            model_name='article',
            name='updateDate',
            field=models.DateField(verbose_name='更新日期'),
        ),
    ]
