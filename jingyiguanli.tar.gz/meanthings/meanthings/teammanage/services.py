from .models import LocalLeanTeam
from django.db.models import Q


# 根据user返回相关的队伍
def getLocalLeanTeamByUser(user):
    objs = LocalLeanTeam.objects.filter(
        Q(leader=user) | Q(member=user))
    return objs
