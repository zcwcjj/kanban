# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='EnterPrise',
            fields=[
                ('id', models.AutoField(auto_created=True, serialize=False, verbose_name='ID', primary_key=True)),
                ('name', models.CharField(max_length=100, verbose_name='企业名称')),
            ],
            options={
                'verbose_name': '企业',
                'verbose_name_plural': '企业',
            },
        ),
        migrations.CreateModel(
            name='LeanTeam',
            fields=[
                ('id', models.AutoField(auto_created=True, serialize=False, verbose_name='ID', primary_key=True)),
                ('name', models.CharField(max_length=100)),
                ('leader', models.ForeignKey(related_name='leader_id', to=settings.AUTH_USER_MODEL)),
                ('member', models.ManyToManyField(related_name='menber_id', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'SiteDepartmentTeam',
                'verbose_name_plural': 'SiteDepartmentTeams',
            },
        ),
        migrations.CreateModel(
            name='Site',
            fields=[
                ('id', models.AutoField(auto_created=True, serialize=False, verbose_name='ID', primary_key=True)),
                ('name', models.CharField(max_length=100, verbose_name='部门或子公司名称')),
                ('code', models.CharField(max_length=20, verbose_name='编码')),
            ],
            options={
                'verbose_name': '部门或子公司',
                'verbose_name_plural': '部门或子公司',
            },
        ),
        migrations.CreateModel(
            name='SiteDepartment',
            fields=[
                ('id', models.AutoField(auto_created=True, serialize=False, verbose_name='ID', primary_key=True)),
                ('name', models.CharField(max_length=100)),
                ('site', models.ForeignKey(to='teammanage.Site')),
            ],
            options={
                'verbose_name': 'SiteDepartment',
                'verbose_name_plural': 'SiteDepartments',
            },
        ),
    ]
