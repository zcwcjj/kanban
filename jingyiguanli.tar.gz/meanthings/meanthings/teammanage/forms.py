from django.forms import ModelForm
from .models import LocalLeanTeam


class LocalLeanTeamCreateForm(ModelForm):
    class Meta:
        model = LocalLeanTeam
        exclude = ('approved',)
        widgets = {

        }
