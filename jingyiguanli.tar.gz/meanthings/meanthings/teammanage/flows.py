from viewflow import flow
from viewflow.base import this, Flow

from viewflow.views import StartProcessView, ProcessView
from .models import LocalLeanTeam


class LocalTeamApply(Flow):
    process_cls = LocalLeanTeam
    process_title = "精益改善团队申请"
    process_description = "精益改善团队申请"
    teamleaderapply = flow.Start(StartProcessView, task_title='申请团队', fields=[
                                 'name', 'leader', 'member', 'site']).Next(this.approve)

    approve = flow.View(ProcessView, fields=['approved']).Permission(
        auto_create=True).Next(this.end)

    end = flow.End()

