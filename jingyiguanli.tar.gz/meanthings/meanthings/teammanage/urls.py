from django.conf.urls import url
from . import views
from viewflow import views as viewflow
from .flows import LocalTeamApply

urlpatterns = [
    # URL pattern for the UserListView
    url(
        regex=r'^create$',
        view=views.LocalLeanTeamCreateView.as_view(),
        name='create'
    ),

    url(
        regex=r'^$',
        view=views.LocalLeanTeamListView.as_view(),
        name='list'
    ),

    url(
        regex=r'^detail/(?P<id>[\w.@+-]+)/$',
        view=views.LocalLeanTeamDetailView.as_view(),
        name='detail'
    ),

    url(
        regex=r'^start/$',
        view=viewflow.ProcessView.as_view(),
        name='start',
        kwargs={'flow_cls': LocalTeamApply}
    ),

    url(
        regex=r'^tasks/$',
        view=viewflow.TaskListView.as_view(),
        name='tasks',
        kwargs={'flow_cls': LocalTeamApply}
    ),

    url(
        regex=r'^queue/$',
        view=viewflow.QueueListView.as_view(),
        name='queue',
        kwargs={'flow_cls': LocalTeamApply}
    ),

    url(
        regex=r'^details/(?P<process_pk>\d+)/$',
        view=viewflow.ProcessDetailView.as_view(),
        name='details',
        kwargs={'flow_cls': LocalTeamApply}
    ),
    LocalTeamApply.instance.urls


]
