from django.shortcuts import render
from django.views.generic import CreateView, DetailView, ListView, RedirectView, UpdateView
from .models import LocalLeanTeam
from .forms import LocalLeanTeamCreateForm
from braces.views import LoginRequiredMixin
from django.core.urlresolvers import reverse
from .services import getLocalLeanTeamByUser

# Create your views here.


class LocalLeanTeamCreateView(LoginRequiredMixin, CreateView):
    model = LocalLeanTeam
    template_name = 'teammanage/local_leanteam_create.html'
    # fields = '__all__'
    form_class = LocalLeanTeamCreateForm
    success_url = '/about'

    def get_success_url(self):
        return reverse("blog:update")


class LocalLeanTeamListView(LoginRequiredMixin, ListView):
    model = LocalLeanTeam
    context_object_name = 'localleanteamlist'
    template_name = 'teammanage/local_leanteam_list.html'

    def get_queryset(self):
        return getLocalLeanTeamByUser(self.request.user)


class LocalLeanTeamDetailView(LoginRequiredMixin, DetailView):
    model = LocalLeanTeam
    template_name = 'teammanage/local_leanteam_detail.html'
    slug_field = 'id'
    slug_url_kwarg = 'id'

    def get_queryset(self):
        return getLocalLeanTeamByUser(self.request.user)
