# -*- coding: utf-8 -*-
from __future__ import unicode_literals, absolute_import

from django.contrib.auth.models import AbstractUser
from django.core.urlresolvers import reverse
from django.db import models
from django.utils.encoding import python_2_unicode_compatible
from django.utils.translation import ugettext_lazy as _


class EnterPrise(models.Model):
    name = models.CharField("企业名称", max_length=100)
    introduce = models.TextField("公司介绍")

    class Meta:
        verbose_name = "企业"
        verbose_name_plural = "企业"

    def __str__(self):
        return self.name


class Site(models.Model):
    name = models.CharField("部门或子公司名称", max_length=100)
    code = models.CharField("编码", max_length=20)
    introduce = models.TextField("部门介绍")
    enterprise = models.ForeignKey(EnterPrise, verbose_name='所属企业')

    class Meta:
        verbose_name = "部门或子公司"
        verbose_name_plural = "部门或子公司"

    def __str__(self):
        return self.name


@python_2_unicode_compatible
class User(AbstractUser):

    # First Name and Last Name do not cover name patterns
    # around the globe.
    name = models.CharField(_("Name of User"), blank=True, max_length=255)
    site = models.ForeignKey(Site, verbose_name='所属部门或子公司', null=True)
    phone_number = models.CharField("电话号码", max_length=20, null=True)

    def __str__(self):
        if self.name:
            return self.name
        return self.username

    def get_absolute_url(self):
        return reverse('users:detail', kwargs={'username': self.username})
