# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('users', '0003_auto_20160714_1032'),
    ]

    operations = [
        migrations.AlterField(
            model_name='user',
            name='phone_number',
            field=models.CharField(null=True, verbose_name='电话号码', max_length=20),
        ),
        migrations.AlterField(
            model_name='user',
            name='site',
            field=models.ForeignKey(null=True, verbose_name='所属部门或子公司', to='users.Site'),
        ),
    ]
