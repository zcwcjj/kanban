from django.conf.urls import url
from django.views.generic import TemplateView
from . import views

urlpatterns = [
    # URL pattern for the UserListView
    url(
        regex=r'^$',
        # view=TemplateView.as_view(template_name='standard/list.html'),
        view=views.StandardListView.as_view(),
        name='list'
    ),
    url(
        regex=r'^(?P<id>[\w.@+-]+)/$',
        view=views.StandardDetailView.as_view(),
        name='detail'
        ),


]
