from django.contrib import admin
from .models import Standard
# Register your models here.

class StandardAdmin(admin.ModelAdmin):
    exclude = ('readUsers',)
    def save_model(self, request, obj, form, change):
        obj.pulish_user = request.user
        obj.save()

admin.site.register(Standard, StandardAdmin)