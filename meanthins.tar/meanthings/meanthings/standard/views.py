from django.shortcuts import render
from django.core.urlresolvers import reverse
from django.views.generic import DetailView, ListView, RedirectView, UpdateView

from braces.views import LoginRequiredMixin
from .models import Standard

# Create your views here.

class StandardDetailView(LoginRequiredMixin, DetailView):
    model = Standard
    template_name = 'standard/standard_detail.html'
    slug_field = 'id'
    slug_url_kwarg = 'id'


class StandardListView(LoginRequiredMixin, ListView):
    model = Standard
    # These next two lines tell the view to index lookups by username
    slug_field = "name"
    slug_url_kwarg = "id"