from django.shortcuts import render
from .models import Article
from django.views.generic import DetailView, ListView, RedirectView, UpdateView, CreateView
from django.core.urlresolvers import reverse
# Create your views here.


class ArticleUpdateView(CreateView):
    model = Article
    template_name = 'blog/blog_detail.html'
    fields = '__all__'
    success_url = '/about'

    def get_success_url(self):
        return reverse("blog:update")
