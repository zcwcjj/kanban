from django.db import models
from django.conf import settings
from meanthings.users.models import Site
from viewflow.models import Process

# Create your models here.



class FirstFormMixin(models.Model):
    name = models.CharField("团队名称", max_length=100)
    leader = models.ForeignKey(
        settings.AUTH_USER_MODEL, related_name='leader_id', verbose_name='团队发起人')
    member = models.ManyToManyField(
        settings.AUTH_USER_MODEL, related_name='member_ids', verbose_name='成员')
    site = models.ForeignKey(Site, verbose_name='所属部门或子公司', null=True)

    class Meta:
        abstract = True


class ApproveMinxin(models.Model):
    approved = models.BooleanField("部门或分公司审批", default=False)

    class Meta:
        abstract = True





class LocalLeanTeam(FirstFormMixin, ApproveMinxin, Process):

    class Meta:
        verbose_name = "精益改善团队"
        verbose_name_plural = "精益改善团队"

    def __str__(self):
        return self.name


class LeanManagerDepartment(models.Model):
    name = models.CharField(max_length=100)

    class Meta:
        verbose_name = "LeanManagerDepartment"
        verbose_name_plural = "LeanManagerDepartments"

    def __str__(self):
        pass
