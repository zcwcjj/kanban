# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('users', '0004_auto_20160714_1034'),
        ('teammanage', '0004_auto_20160714_1459'),
    ]

    operations = [
        migrations.AddField(
            model_name='localleanteam',
            name='approved',
            field=models.BooleanField(default=False, verbose_name='部门或分公司审批'),
        ),
        migrations.AddField(
            model_name='localleanteam',
            name='site',
            field=models.ForeignKey(null=True, to='users.Site', verbose_name='所属部门或子公司'),
        ),
        migrations.AlterField(
            model_name='localleanteam',
            name='leader',
            field=models.ForeignKey(related_name='leader_id', to=settings.AUTH_USER_MODEL, verbose_name='团队发起人'),
        ),
        migrations.AlterField(
            model_name='localleanteam',
            name='member',
            field=models.ManyToManyField(related_name='member_ids', to=settings.AUTH_USER_MODEL, verbose_name='成员'),
        ),
        migrations.AlterField(
            model_name='localleanteam',
            name='name',
            field=models.CharField(max_length=100, verbose_name='团队名称'),
        ),
    ]
