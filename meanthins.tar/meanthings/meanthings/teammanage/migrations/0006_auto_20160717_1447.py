# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('users', '0004_auto_20160714_1034'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('teammanage', '0005_auto_20160715_1505'),
    ]

    operations = [
        migrations.CreateModel(
            name='FirstFormMixin',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, primary_key=True, auto_created=True)),
                ('name', models.CharField(max_length=100, verbose_name='团队名称')),
                ('leader', models.ForeignKey(verbose_name='团队发起人', related_name='leader_id', to=settings.AUTH_USER_MODEL)),
                ('member', models.ManyToManyField(related_name='member_ids', verbose_name='成员', to=settings.AUTH_USER_MODEL)),
                ('site', models.ForeignKey(null=True, verbose_name='所属部门或子公司', to='users.Site')),
            ],
        ),
        migrations.RemoveField(
            model_name='localleanteam',
            name='id',
        ),
        migrations.RemoveField(
            model_name='localleanteam',
            name='leader',
        ),
        migrations.RemoveField(
            model_name='localleanteam',
            name='member',
        ),
        migrations.RemoveField(
            model_name='localleanteam',
            name='name',
        ),
        migrations.RemoveField(
            model_name='localleanteam',
            name='site',
        ),
        migrations.AddField(
            model_name='localleanteam',
            name='firstformmixin_ptr',
            field=models.OneToOneField(parent_link=True, default=1, serialize=False, auto_created=True, to='teammanage.FirstFormMixin', primary_key=True),
            preserve_default=False,
        ),
    ]
