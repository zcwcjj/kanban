from django.db import models
from django.conf import settings

# Create your models here.

class Standard(models.Model):
    name = models.CharField(max_length=50)
    content = models.TextField()
    Attachment = models.FileField(upload_to='Standard', verbose_name='附件')
    readUsers = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='readers')
    publish_date = models.DateTimeField(auto_now=True)
    publish_user = models.ForeignKey(settings.AUTH_USER_MODEL, verbose_name='发布者', null=True, editable=False)


    class Meta:
        verbose_name = "标准"
        verbose_name_plural = "标准"

    def __str__(self):
        return self.name
    
