from viewflow import flow
from viewflow.base import this, Flow

from viewflow.views import StartProcessView, ProcessView
from .models import LocalLeanTeam


class LocalTeamApply(Flow):
    process_cls = LocalLeanTeam

    teamleaderapply = flow.Start(StartProcessView, fields=[
                                 'name', 'leader', 'member', 'site']).Next(this.approve)

    approve = flow.View(ProcessView, fields=['approved']).Permission(
        auto_create=True).Next(this.end)

    end = flow.End()
