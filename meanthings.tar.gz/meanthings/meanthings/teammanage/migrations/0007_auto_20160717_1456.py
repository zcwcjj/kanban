# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('users', '0004_auto_20160714_1034'),
        ('teammanage', '0006_auto_20160717_1447'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='firstformmixin',
            name='leader',
        ),
        migrations.RemoveField(
            model_name='firstformmixin',
            name='member',
        ),
        migrations.RemoveField(
            model_name='firstformmixin',
            name='site',
        ),
        migrations.RemoveField(
            model_name='localleanteam',
            name='firstformmixin_ptr',
        ),
        migrations.AddField(
            model_name='localleanteam',
            name='id',
            field=models.AutoField(default=1, verbose_name='ID', serialize=False, primary_key=True, auto_created=True),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='localleanteam',
            name='leader',
            field=models.ForeignKey(default=1, to=settings.AUTH_USER_MODEL, verbose_name='团队发起人', related_name='leader_id'),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='localleanteam',
            name='member',
            field=models.ManyToManyField(to=settings.AUTH_USER_MODEL, verbose_name='成员', related_name='member_ids'),
        ),
        migrations.AddField(
            model_name='localleanteam',
            name='name',
            field=models.CharField(default=1, verbose_name='团队名称', max_length=100),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='localleanteam',
            name='site',
            field=models.ForeignKey(to='users.Site', verbose_name='所属部门或子公司', null=True),
        ),
        migrations.DeleteModel(
            name='FirstFormMixin',
        ),
    ]
