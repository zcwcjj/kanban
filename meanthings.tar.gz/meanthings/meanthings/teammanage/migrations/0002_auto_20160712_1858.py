# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('teammanage', '0001_initial'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='leanteam',
            options={'verbose_name': '精益改善团队', 'verbose_name_plural': '精益改善团队'},
        ),
        migrations.AlterModelOptions(
            name='sitedepartment',
            options={'verbose_name': '分部门', 'verbose_name_plural': '分部门'},
        ),
    ]
