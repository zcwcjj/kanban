# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('teammanage', '0002_auto_20160712_1858'),
    ]

    operations = [
        migrations.CreateModel(
            name='LeanManagerDepartment',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('name', models.CharField(max_length=100)),
            ],
            options={
                'verbose_name_plural': 'LeanManagerDepartments',
                'verbose_name': 'LeanManagerDepartment',
            },
        ),
        migrations.CreateModel(
            name='LocalLeanTeam',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('name', models.CharField(max_length=100)),
                ('leader', models.ForeignKey(to=settings.AUTH_USER_MODEL, related_name='leader_id')),
                ('member', models.ManyToManyField(related_name='member_ids', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name_plural': '精益改善团队',
                'verbose_name': '精益改善团队',
            },
        ),
        migrations.RemoveField(
            model_name='leanteam',
            name='leader',
        ),
        migrations.RemoveField(
            model_name='leanteam',
            name='member',
        ),
        migrations.RemoveField(
            model_name='sitedepartment',
            name='site',
        ),
        migrations.AddField(
            model_name='enterprise',
            name='introduce',
            field=models.TextField(verbose_name='公司介绍', default='tset'),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='site',
            name='enterprise',
            field=models.ForeignKey(to='teammanage.EnterPrise', default=1, verbose_name='所属企业'),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='site',
            name='introduce',
            field=models.TextField(verbose_name='部门介绍', default=1),
            preserve_default=False,
        ),
        migrations.DeleteModel(
            name='LeanTeam',
        ),
        migrations.DeleteModel(
            name='SiteDepartment',
        ),
    ]
