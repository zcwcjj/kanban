# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('users', '0002_auto_20160705_1326'),
    ]

    operations = [
        migrations.CreateModel(
            name='EnterPrise',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('name', models.CharField(max_length=100, verbose_name='企业名称')),
                ('introduce', models.TextField(verbose_name='公司介绍')),
            ],
            options={
                'verbose_name_plural': '企业',
                'verbose_name': '企业',
            },
        ),
        migrations.CreateModel(
            name='Site',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('name', models.CharField(max_length=100, verbose_name='部门或子公司名称')),
                ('code', models.CharField(max_length=20, verbose_name='编码')),
                ('introduce', models.TextField(verbose_name='部门介绍')),
                ('enterprise', models.ForeignKey(to='users.EnterPrise', verbose_name='所属企业')),
            ],
            options={
                'verbose_name_plural': '部门或子公司',
                'verbose_name': '部门或子公司',
            },
        ),
        migrations.AddField(
            model_name='user',
            name='phone_number',
            field=models.CharField(max_length=20, verbose_name='电话号码', default='123123123123'),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='user',
            name='site',
            field=models.ForeignKey(to='users.Site', default=1, verbose_name='所属部门或子公司'),
            preserve_default=False,
        ),
    ]
