from django.db import models

# Create your models here.
class Timelogable(models.Model):
	createDate = models.DateField("填写日期")
	updateDate = models.DateField("更新日期")
	class Meta:
		abstract = True


class Article(Timelogable):
	title = models.CharField("标题",max_length=100)
	content = models.TextField("内容",max_length=5000)
